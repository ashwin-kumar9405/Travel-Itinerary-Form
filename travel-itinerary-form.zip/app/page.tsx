import Header from "../components/Header"
import TravelItineraryForm from "../components/TravelItineraryForm"

export default function Page() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="py-8">
        <TravelItineraryForm />
      </main>
      <footer className="bg-white border-t border-gray-200 py-6 mt-12">
        <div className="max-w-6xl mx-auto px-6 text-center text-sm text-gray-600">
          <p>&copy; 2024 VigOvia Travel Solutions. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
