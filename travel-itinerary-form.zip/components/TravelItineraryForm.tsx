"use client"

import type React from "react"
import { useState } from "react"
import FormSection from "./FormSection"
import InputField from "./InputField"
import TextAreaField from "./TextAreaField"
import ActivityTable from "./ActivityTable"
import PDFDownloadButton from "./PDFDownloadButton"

interface Activity {
  id: string
  day: string
  time: string
  activity: string
  location: string
  notes: string
}

const TravelItineraryForm: React.FC = () => {
  const [destination, setDestination] = useState("")
  const [clientName, setClientName] = useState("")
  const [travelDates, setTravelDates] = useState("")
  const [groupSize, setGroupSize] = useState("")
  const [importantNotes, setImportantNotes] = useState("")
  const [scopeOfService, setScopeOfService] = useState("")
  const [inclusionSummary, setInclusionSummary] = useState("")
  const [termsAndConditions, setTermsAndConditions] = useState("")
  const [activities, setActivities] = useState<Activity[]>([
    {
      id: "1",
      day: "Day 1",
      time: "09:00 AM",
      activity: "Airport Transfer",
      location: "Changi Airport",
      notes: "Meet at arrival hall",
    },
  ])

  const formData = {
    destination,
    clientName,
    travelDates,
    groupSize,
    importantNotes,
    scopeOfService,
    inclusionSummary,
    activities,
    termsAndConditions,
  }

  const isFormValid = destination && clientName && travelDates && groupSize

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Basic Information */}
      <FormSection title="Basic Information">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InputField
            label="Destination"
            value={destination}
            onChange={setDestination}
            placeholder="e.g., Singapore"
            required
          />
          <InputField
            label="Client Name"
            value={clientName}
            onChange={setClientName}
            placeholder="Enter client name"
            required
          />
          <InputField
            label="Travel Dates"
            value={travelDates}
            onChange={setTravelDates}
            placeholder="e.g., March 15-22, 2024"
            required
          />
          <InputField
            label="Group Size"
            value={groupSize}
            onChange={setGroupSize}
            placeholder="e.g., 4 adults"
            required
          />
        </div>
      </FormSection>

      {/* Important Notes */}
      <FormSection title="Important Notes">
        <TextAreaField
          label="Important Information"
          value={importantNotes}
          onChange={setImportantNotes}
          placeholder="Enter any important notes, requirements, or special instructions..."
          rows={4}
        />
      </FormSection>

      {/* Scope of Service */}
      <FormSection title="Scope of Service">
        <TextAreaField
          label="Services Included"
          value={scopeOfService}
          onChange={setScopeOfService}
          placeholder="Describe the services included in this travel package..."
          rows={5}
        />
      </FormSection>

      {/* Inclusion Summary */}
      <FormSection title="Inclusion Summary">
        <TextAreaField
          label="What's Included"
          value={inclusionSummary}
          onChange={setInclusionSummary}
          placeholder="List all inclusions such as accommodation, meals, transportation, etc..."
          rows={5}
        />
      </FormSection>

      {/* Activity Table */}
      <FormSection title="Activity Schedule">
        <ActivityTable activities={activities} onActivitiesChange={setActivities} />
      </FormSection>

      {/* Terms and Conditions */}
      <FormSection title="Terms and Conditions">
        <TextAreaField
          label="Terms & Conditions"
          value={termsAndConditions}
          onChange={setTermsAndConditions}
          placeholder="Enter terms and conditions for this travel package..."
          rows={6}
        />
      </FormSection>

      {/* PDF Download Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">Generate Itinerary PDF</h3>
            <p className="text-sm text-gray-600 mt-1">
              Download a professionally formatted PDF of your travel itinerary
            </p>
          </div>
          <PDFDownloadButton formData={formData} className={!isFormValid ? "opacity-50 cursor-not-allowed" : ""} />
        </div>
        {!isFormValid && (
          <p className="text-sm text-red-600 mt-2">
            Please fill in all required fields (Destination, Client Name, Travel Dates, Group Size) before downloading.
          </p>
        )}
      </div>
    </div>
  )
}

export default TravelItineraryForm
