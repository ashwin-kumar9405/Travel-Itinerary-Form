import type React from "react"

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b-2 border-blue-500 p-4">
      <div className="max-w-4xl mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div className="text-2xl font-bold">
            <span className="text-purple-600">vigo</span>
            <span className="text-gray-800">via</span>
          </div>
        </div>
        <div className="text-sm text-gray-600">Travel Itinerary Generator</div>
      </div>
    </header>
  )
}

export default Header
