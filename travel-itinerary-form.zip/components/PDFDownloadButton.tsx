"use client"

import type React from "react"

interface FormData {
  destination: string
  clientName: string
  travelDates: string
  groupSize: string
  importantNotes: string
  scopeOfService: string
  inclusionSummary: string
  activities: Array<{
    id: string
    day: string
    time: string
    activity: string
    location: string
    notes: string
  }>
  termsAndConditions: string
}

interface PDFDownloadButtonProps {
  formData: FormData
  className?: string
}

const PDFDownloadButton: React.FC<PDFDownloadButtonProps> = ({ formData, className = "" }) => {
  const generatePDF = async () => {
    try {
      // Dynamic import to avoid SSR issues
      const jsPDF = (await import("jspdf")).default
      const autoTable = (await import("jspdf-autotable")).default

      const doc = new jsPDF()
      const pageWidth = doc.internal.pageSize.width
      const margin = 20

      // Header with VigOvia branding
      doc.setFillColor(102, 51, 153) // Purple color
      doc.rect(0, 0, pageWidth, 30, "F")

      doc.setTextColor(255, 255, 255)
      doc.setFontSize(24)
      doc.setFont("helvetica", "bold")
      doc.text("vigovia", margin, 20)

      doc.setFontSize(14)
      doc.setFont("helvetica", "normal")
      doc.text("Travel Itinerary", pageWidth - margin - 50, 20)

      // Reset text color for content
      doc.setTextColor(0, 0, 0)
      let yPosition = 50

      // Title
      doc.setFontSize(18)
      doc.setFont("helvetica", "bold")
      doc.text(`${formData.destination} Itinerary`, margin, yPosition)
      yPosition += 15

      // Basic Information
      doc.setFontSize(12)
      doc.setFont("helvetica", "normal")
      doc.text(`Client: ${formData.clientName}`, margin, yPosition)
      yPosition += 8
      doc.text(`Travel Dates: ${formData.travelDates}`, margin, yPosition)
      yPosition += 8
      doc.text(`Group Size: ${formData.groupSize}`, margin, yPosition)
      yPosition += 15

      // Important Notes Section
      if (formData.importantNotes) {
        doc.setFont("helvetica", "bold")
        doc.text("Important Notes", margin, yPosition)
        yPosition += 8
        doc.setFont("helvetica", "normal")
        const notesLines = doc.splitTextToSize(formData.importantNotes, pageWidth - 2 * margin)
        doc.text(notesLines, margin, yPosition)
        yPosition += notesLines.length * 5 + 10
      }

      // Check if we need a new page
      if (yPosition > 250) {
        doc.addPage()
        yPosition = 20
      }

      // Activities Table
      if (formData.activities.length > 0) {
        doc.setFont("helvetica", "bold")
        doc.text("Activity Schedule", margin, yPosition)
        yPosition += 10

        const tableData = formData.activities.map((activity) => [
          activity.day,
          activity.time,
          activity.activity,
          activity.location,
          activity.notes,
        ])

        autoTable(doc, {
          head: [["Day", "Time", "Activity", "Location", "Notes"]],
          body: tableData,
          startY: yPosition,
          theme: "grid",
          headStyles: {
            fillColor: [102, 51, 153],
            textColor: [255, 255, 255],
            fontStyle: "bold",
          },
          styles: {
            fontSize: 10,
            cellPadding: 3,
          },
          columnStyles: {
            0: { cellWidth: 25 },
            1: { cellWidth: 25 },
            2: { cellWidth: 40 },
            3: { cellWidth: 35 },
            4: { cellWidth: 35 },
          },
        })

        yPosition = (doc as any).lastAutoTable.finalY + 15
      }

      // Add new page if needed for remaining sections
      if (yPosition > 200) {
        doc.addPage()
        yPosition = 20
      }

      // Scope of Service
      if (formData.scopeOfService) {
        doc.setFont("helvetica", "bold")
        doc.text("Scope of Service", margin, yPosition)
        yPosition += 8
        doc.setFont("helvetica", "normal")
        const scopeLines = doc.splitTextToSize(formData.scopeOfService, pageWidth - 2 * margin)
        doc.text(scopeLines, margin, yPosition)
        yPosition += scopeLines.length * 5 + 10
      }

      // Inclusion Summary
      if (formData.inclusionSummary) {
        doc.setFont("helvetica", "bold")
        doc.text("Inclusion Summary", margin, yPosition)
        yPosition += 8
        doc.setFont("helvetica", "normal")
        const inclusionLines = doc.splitTextToSize(formData.inclusionSummary, pageWidth - 2 * margin)
        doc.text(inclusionLines, margin, yPosition)
        yPosition += inclusionLines.length * 5 + 10
      }

      // Terms and Conditions
      if (formData.termsAndConditions) {
        if (yPosition > 200) {
          doc.addPage()
          yPosition = 20
        }
        doc.setFont("helvetica", "bold")
        doc.text("Terms and Conditions", margin, yPosition)
        yPosition += 8
        doc.setFont("helvetica", "normal")
        const termsLines = doc.splitTextToSize(formData.termsAndConditions, pageWidth - 2 * margin)
        doc.text(termsLines, margin, yPosition)
      }

      // Footer
      const pageCount = doc.internal.getNumberOfPages()
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i)
        doc.setFontSize(10)
        doc.setTextColor(128, 128, 128)
        doc.text(`Page ${i} of ${pageCount}`, pageWidth - margin - 20, doc.internal.pageSize.height - 10)
        doc.text("Generated by VigOvia Travel Itinerary System", margin, doc.internal.pageSize.height - 10)
      }

      // Save the PDF
      const fileName = `${formData.destination.replace(/\s+/g, "_")}_Itinerary.pdf`
      doc.save(fileName)
    } catch (error) {
      console.error("Error generating PDF:", error)
      alert("Error generating PDF. Please try again.")
    }
  }

  return (
    <button
      onClick={generatePDF}
      className={`bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 flex items-center space-x-2 ${className}`}
    >
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
        />
      </svg>
      <span>Download PDF</span>
    </button>
  )
}

export default PDFDownloadButton
