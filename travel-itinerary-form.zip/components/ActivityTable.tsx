"use client"

import type React from "react"

interface Activity {
  id: string
  day: string
  time: string
  activity: string
  location: string
  notes: string
}

interface ActivityTableProps {
  activities: Activity[]
  onActivitiesChange: (activities: Activity[]) => void
}

const ActivityTable: React.FC<ActivityTableProps> = ({ activities, onActivitiesChange }) => {
  const addActivity = () => {
    const newActivity: Activity = {
      id: Date.now().toString(),
      day: "",
      time: "",
      activity: "",
      location: "",
      notes: "",
    }
    onActivitiesChange([...activities, newActivity])
  }

  const updateActivity = (id: string, field: keyof Activity, value: string) => {
    const updatedActivities = activities.map((activity) =>
      activity.id === id ? { ...activity, [field]: value } : activity,
    )
    onActivitiesChange(updatedActivities)
  }

  const removeActivity = (id: string) => {
    const filteredActivities = activities.filter((activity) => activity.id !== id)
    onActivitiesChange(filteredActivities)
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse border border-gray-300">
        <thead>
          <tr className="bg-purple-100">
            <th className="border border-gray-300 px-3 py-2 text-left text-sm font-semibold">Day</th>
            <th className="border border-gray-300 px-3 py-2 text-left text-sm font-semibold">Time</th>
            <th className="border border-gray-300 px-3 py-2 text-left text-sm font-semibold">Activity</th>
            <th className="border border-gray-300 px-3 py-2 text-left text-sm font-semibold">Location</th>
            <th className="border border-gray-300 px-3 py-2 text-left text-sm font-semibold">Notes</th>
            <th className="border border-gray-300 px-3 py-2 text-center text-sm font-semibold">Action</th>
          </tr>
        </thead>
        <tbody>
          {activities.map((activity) => (
            <tr key={activity.id} className="hover:bg-gray-50">
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="text"
                  value={activity.day}
                  onChange={(e) => updateActivity(activity.id, "day", e.target.value)}
                  className="w-full px-2 py-1 text-sm border-none focus:outline-none"
                  placeholder="Day 1"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="text"
                  value={activity.time}
                  onChange={(e) => updateActivity(activity.id, "time", e.target.value)}
                  className="w-full px-2 py-1 text-sm border-none focus:outline-none"
                  placeholder="09:00 AM"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="text"
                  value={activity.activity}
                  onChange={(e) => updateActivity(activity.id, "activity", e.target.value)}
                  className="w-full px-2 py-1 text-sm border-none focus:outline-none"
                  placeholder="Activity name"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="text"
                  value={activity.location}
                  onChange={(e) => updateActivity(activity.id, "location", e.target.value)}
                  className="w-full px-2 py-1 text-sm border-none focus:outline-none"
                  placeholder="Location"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="text"
                  value={activity.notes}
                  onChange={(e) => updateActivity(activity.id, "notes", e.target.value)}
                  className="w-full px-2 py-1 text-sm border-none focus:outline-none"
                  placeholder="Notes"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1 text-center">
                <button
                  onClick={() => removeActivity(activity.id)}
                  className="text-red-500 hover:text-red-700 text-sm font-medium"
                >
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button
        onClick={addActivity}
        className="mt-3 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors text-sm font-medium"
      >
        Add Activity
      </button>
    </div>
  )
}

export default ActivityTable
