import type React from "react"

interface FormSectionProps {
  title: string
  children: React.ReactNode
  className?: string
}

const FormSection: React.FC<FormSectionProps> = ({ title, children, className = "" }) => {
  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden ${className}`}>
      <div className="bg-purple-600 text-white px-4 py-3">
        <h2 className="text-lg font-semibold">{title}</h2>
      </div>
      <div className="p-4">{children}</div>
    </div>
  )
}

export default FormSection
